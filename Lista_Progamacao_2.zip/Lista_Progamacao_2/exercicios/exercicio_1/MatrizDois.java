package exercicio_1;

import java.util.Scanner;

public class MatrizDois {
	
	/**
	 * Imprime uma matriz nxm
	 * 
	 * @param matriz
	 *            de inteiros
	 */
	public static void imprimeMatriz(int[][] matriz) {
		for (int i = 0; i < matriz.length; i++) {
			// imprimindo a linha da matriz
			for (int j = 0; j < matriz[0].length; j++) {
				System.out.print(matriz[i][j] + " ");
			}
			// pula a linha da matriz
			System.out.println("");
		}
	}

	/**
	 * 
	 * @return uma matriz solicitada ao usu�rio
	 * onde o usu�rio vai informar os valores para as linhas da matriz
	 */
	public static int[][] solicitaMatriz(int linhas, int colunas) {
		Scanner scan = new Scanner(System.in);
		int[][] matriz = new int[linhas][colunas];
		for (int i = 0; i < linhas; i++) {
			for (int j = 0; j < colunas; j++) {
				System.out.println("Digite o valor para linha " + i + ", coluna " + j);
				matriz[i][j] = scan.nextInt();
			}
		}
		return matriz;
	}

	/**
	 * Multiplica duas matrizes nxm*mxk
	 * 
	 * @param matrizUm
	 * @param matrizDois
	 * @return
	 */
	public static int[][] multiplicaMatrizes(int[][] matrizUm, int[][] matrizDois) {
		// matriz resultante com nova dimens�o mistra entre matrizUm e
		// matrizDois
		int[][] resultante = new int[matrizUm[0].length][matrizDois.length];
		// percorrendo as matrizes
		for (int i = 0; i < matrizUm[0].length; i++) {
			for (int j = 0; j < matrizDois.length; j++) {
				// multiplica a linha i pela coluna j
				resultante[i][j] = multiplicaLinhaColuna(matrizUm[i], pegaColuna(j, matrizDois));
			}
		}
		return resultante;
	}

	/**
	 * Pega uma coluna de uma matriz
	 * 
	 * @param coluna
	 *            inteiro que representa o index da coluna
	 * @param matriz
	 *            matriz a ser consultada a coluna
	 * @return coluna de inteiros
	 */
	public static int[] pegaColuna(int coluna, int[][] matriz) {
		// novo vetor do tamanho de linhas da matriz
		int[] resultado = new int[matriz.length];
		// para cada linha pegue o valor da coluna na posi��o 'int coluna'
		for (int i = 0; i < matriz.length; i++) {
			resultado[i] = matriz[i][coluna];
		}
		return resultado;
	}

	/**
	 * Multiplica dois vetores de mesma dimens�o
	 * 
	 * @param linha
	 *            vetor de inteiros
	 * @param coluna
	 *            vetor de inteiros
	 * @return somat�rio do produto da linha pelo coluna
	 */
	public static int multiplicaLinhaColuna(int[] linha, int[] coluna) {
		int result = 0;
		// somando a multiplica��o da linha pela coluna e acumula o somat�rio em
		// 'result'
		for (int i = 0; i < linha.length; i++) {
			result = result + linha[i] * coluna[i];
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int linMatrizUm, colMatrizUm, linMatrizDois, colMatrizDois;

		System.out.println("Digite o n�mero de linhas da matriz um:");
		linMatrizUm = scan.nextInt();
		System.out.println("Digite o n�mero de colunas da matriz um:");
		colMatrizUm = scan.nextInt();

		System.out.println("Digite o n�mero de linhas da matriz dois:");
		linMatrizDois = scan.nextInt();
		System.out.println("Digite o n�mero de colunas da matriz dois:");
		colMatrizDois = scan.nextInt();

		if (colMatrizUm != linMatrizDois) {
			System.out.println("N�o ser� poss�vel multiplicar matrizes destas dimens�es");
		} else {
			System.out.println("Dados da matriz Um: ");
			int[][] matrizUm = solicitaMatriz(linMatrizUm, colMatrizUm);
			System.out.println("Dados da matriz Dois: ");
			int[][] matrizDois = solicitaMatriz(linMatrizDois, colMatrizDois);
			int[][] matrizResultante = multiplicaMatrizes(matrizUm, matrizDois);

			System.out.println("Matriz Um:");
			imprimeMatriz(matrizUm);

			System.out.println("\nMatriz Dois:");
			imprimeMatriz(matrizDois);

			System.out.println("\nMatriz Resultante de matrizUm x matrizDois:");
			imprimeMatriz(matrizResultante);
		}
	}

}
