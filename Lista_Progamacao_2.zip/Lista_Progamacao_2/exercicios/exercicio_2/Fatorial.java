package exercicio_2;

import java.util.Scanner;

public class Fatorial {

	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		System.out.print("Informe o desejado: ");
		int fat = entrada.nextInt();
		int num = fat;
		
		int resultado = fat;
		
		if (fat == 0){
			System.out.print(fat+"!= "+fat);
		}
		if (fat>0){
			System.out.print(fat+"!= "+num);
			
			
			for (int x=1; x < fat; x++){
				num-=1;
				
				int operador = resultado*num;
				resultado = operador;
				System.out.print("*"+num);
			}
			System.out.print(" ="+resultado);
		}
		

	}

}
