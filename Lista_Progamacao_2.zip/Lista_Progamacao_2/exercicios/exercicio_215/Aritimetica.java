package exercicio_215;

import java.util.Scanner;

public class Aritimetica {
	
	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		System.out.println("Insira um n�mero inteiro: ");
		int num1 = entrada.nextInt();
		
		
		Scanner entrada2 = new Scanner(System.in);
		System.out.println("Insira outro n�mero inteiro:");
		int num2 = entrada2.nextInt();
		
		int soma, subtracao, divisao, produto;
		
		soma = num1+num2;
		subtracao = num1-num2;
		divisao = num1/num2;
		produto = num1*num2;
		
		System.out.println("O resultado da soma dos n�meros informados foi: "+soma);
		System.out.println("O resultado da subtra��o dos n�meros informados foi: "+subtracao);
		System.out.println("O resultado da divis�o dos n�meros informados foi: "+divisao);
		System.out.println("O resultado do produto dos n�meros informados foi: "+produto);
		
		
	}
		
}


