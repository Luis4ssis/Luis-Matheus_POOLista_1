package exercicio_216;

import java.util.Scanner;

public class ComparandoInteiros {

	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		System.out.print("Insira um n�mero inteiro: ");
		int num1 = entrada.nextInt();
		
		Scanner entrada2 = new Scanner(System.in);
		System.out.print("Insira outro n�mero inteiro: ");
		int num2 = entrada2.nextInt();
		
		if (num1 > num2){
			System.out.println(num1+" Its larger!");
		}
		if (num2 > num1){
			System.out.println(num2+" Its larger!");
		}
		if (num1 == num2){
			System.out.println("These number are equal!");
		}

	}

}
