package exercicio_218;

public class ExibindoFormasAsteriscos {

	public static void main(String[] args) {
		
		System.out.println("*********     ***       *        *    ");
		System.out.println("*       *   *     *    ***      * *   ");
		System.out.println("*       *  *       *  *****    *   *  ");
		System.out.println("*       *  *       *    *     *     * ");
		System.out.println("*       *  *       *    *    *       *");
		System.out.println("*       *  *       *    *     *     * ");
		System.out.println("*       *  *       *    *      *   *  ");
		System.out.println("*       *   *     *     *       * *   ");
		System.out.println("*********     ***       *        *    ");
		

	}

}
