package exercicio_224;

import java.util.Scanner;

public class MaioresMenores {

	public static void main(String[] args) {
		
		int cont = 0;
		
		double maior = 0;
		double menor = 0;
		
		for (int x=1;x<=5;x++){
			
			cont+=1;
			Scanner entrada = new Scanner(System.in);
			System.out.print("Informe o "+cont+"� n�mero: ");
			double num = entrada.nextDouble();
			
			if (x==1){
				maior=num;
				menor=num;
			}if (num >= maior){
				maior=num;
			}if (num < menor){
				menor=num;
			}					
		}
		System.out.println("O maior n�mero informado foi: "+maior);
		System.out.println("O menor n�mero informado foi: "+menor);
	}

}
