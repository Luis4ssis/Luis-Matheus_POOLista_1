package exercicio_225;

import java.util.Scanner;

public class ImparPar {

	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		System.out.print("Informe um n�mero inteiro: ");
		int num = entrada.nextInt();
		
		if (num % 2 == 0){
			System.out.print("O n�mero informado � Par.");
		}
		else{
			System.out.print("O n�mero informado � �mpar.");
		}
	}

}
