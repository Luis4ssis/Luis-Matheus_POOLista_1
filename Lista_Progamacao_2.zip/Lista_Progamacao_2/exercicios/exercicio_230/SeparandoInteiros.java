package exercicio_230;

import java.util.Scanner;

public class SeparandoInteiros {

	public static void main(String[] args) {
	
		while(true){
		
			Scanner entrada = new Scanner(System.in);
			System.out.println("Informe um valor inteiro com 5 d�gitos: ");
			int num = entrada.nextInt();
			
			char[] digitos = String.valueOf( num ).toCharArray();
			int tamanho = digitos.length;
			
			if (tamanho > 5 || tamanho <5){
				System.out.println("N�mero informado inv�lido");				
			}
			else{
				for ( char x : digitos ) {
				    System.out.print( x + "   " );  
				}
				break;
			}
		}       
	}
}
