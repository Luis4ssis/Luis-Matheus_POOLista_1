package exercicio_232;

import java.util.Scanner;

public class NegativosPositivosZeros {

	public static void main(String[] args) {
		int positivo = 0;
		int negativo = 0;
		int zero = 0;
		for(int x = 1; x<=5; x++){          
			Scanner entrada = new Scanner(System.in);
			System.out.print("Informe um n�mero:");
			double num = entrada.nextDouble();	            
			if(num > 0){
				positivo+=1;
				}
			if(num <0){
				negativo+=1;
				}
			if(num == 0){
				zero+=1;              
				}
		}
			
		System.out.println(positivo+"=Positivos");
		System.out.println(negativo+"=negativios");
		System.out.println(zero+"=zero");
	
	}
}



