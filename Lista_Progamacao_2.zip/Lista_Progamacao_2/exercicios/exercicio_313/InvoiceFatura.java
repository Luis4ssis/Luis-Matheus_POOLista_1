package exercicio_313;

public class InvoiceFatura {
	
	public static void main(String[] args) {
		
		Invoice f1 = new Invoice("123","teclado", 20, 65.20);
		
		System.out.println(f1.getInvoiceAmount());
		
		f1.setPreco(70);
		System.out.println(f1.getInvoiceAmount());
		
	}

}
