package exercicio_314;

import java.util.Scanner;

public class EmployeeTest {
	
	public static void main(String[] args){ 
		
		Scanner entrada =  new Scanner(System.in);
		System.out.println("Informe a quantidade de fucion�rios ser�o entrvistados: ");
		int quant = entrada.nextInt();
		
		for(int i = 0; i < quant; i++){
			System.out.println("Informe o nome do "+ (i+1) +"� funcion�rio: ");
			Scanner entrada2 =  new Scanner(System.in);
			String name = entrada2.next();
			
			System.out.println("Informe o sobrenome do "+ (i+1) +"� funcion�rio: ");
			Scanner entrada3 =  new Scanner(System.in);
			String sobrename = entrada3.next();
			
			System.out.println("Informe o sal�rio do "+ (i+1) +"� funcion�rio: ");
			Scanner entrada4 =  new Scanner(System.in);
			double salary = entrada4.nextDouble();
			System.out.println(" ");
			
			Employee f2 = new Employee(name,sobrename,salary);
			f2.getEmployee();
			System.out.println("O sal�rio anual com o aumento de 10% � igual � R$ "+f2.Aumento());
			System.out.println(" ");
		}
		
		
	}

}
