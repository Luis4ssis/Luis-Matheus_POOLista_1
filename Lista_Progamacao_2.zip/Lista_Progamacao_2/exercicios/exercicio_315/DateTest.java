package exercicio_315;

import java.util.Scanner;

public class DateTest {
	
	public static void main(String[] args){
		
		Scanner entrada = new Scanner(System.in);
		System.out.println("Informe o dia: ");
		int day = entrada.nextInt();
		if (day > 32){
			System.out.println("Valor invalido!");
		}
		
		Scanner entrada2 = new Scanner(System.in);
		System.out.println("Informe o m�s: ");
		int month = entrada2.nextInt();
		if (month > 12){
			System.out.println("Valor invalido!");
		}
		
		Scanner entrada3 = new Scanner(System.in);
		System.out.println("Informe o ano: ");
		int year = entrada3.nextInt();
		if (year <= 0){
			System.out.println("Valor invalido!");
		}
		
		
		Date data = new Date(day,month,year);
		data.getdisplayDate();
			
	}

}

