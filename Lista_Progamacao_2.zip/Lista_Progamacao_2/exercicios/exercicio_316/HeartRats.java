package exercicio_316;

public class HeartRats {
	
	private String nome;
	private String sobrenome;
	private String sexo;
	private int dia;
	private int mes;
	private int ano;
	
	
	//construtor
	public HeartRats(String nome, String sobrenome,String sexo,int dia, int mes, int ano) {
		
		this.nome = nome;
		this.sobrenome = sobrenome;
		this.sexo = sexo;
		this.dia = dia;
		this.mes = mes;
		this.ano = ano;
	}
	//nome
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	//sobre nome
	public String getSobrenome() {
		return sobrenome;
	}
	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}
	//sexo
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	//dia
	public int getDia() {
		return dia;
	}
	public void setDia(int dia) {
		this.dia = dia;
	}
	//mes
	public int getMes() {
		return mes;
	}
	public void setMes(int mes) {
		this.mes = mes;
	}
	//ano
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	public String Namecmplet(){
		String nomePaciente = nome +" "+ sobrenome;
		return nomePaciente;
	}
	public String Sexo(){
		String sexoPaciente = sexo;
		return sexoPaciente;
	}
	//idade
	public int Age(){
		return 2016 - ano;
	}
	//frequencia cardiaca
	public int Frequencia(){
		int freqCard = 220 - Age();
		return freqCard;
	}
	//50% intervalo da frequencia cardiaca 
	public double Intervalo(){
		double interv = Frequencia() * 0.50;
		return interv;

	}
	//85% intervalo da frequencia cardiaca
	public double Intervalo2(){
		double interv2 = Frequencia() * 0.85;
		return interv2;
	}
	
}
	

