package exercicio_316;

import java.util.Scanner;

import exercicio_313.Invoice;

public class HeartRatsTest {
	
	public static void main(String[] args){
		
		// entrada recebe o nome do paciente!
		Scanner entrada = new Scanner(System.in);
		System.out.println("Informe a quantidade de pacientes que ser�o informados: ");
		int quant = entrada.nextInt();
		
		for(int i = 0; i < quant; i++){
			System.out.println("Informe o primeiro nome do "+(i+1)+"� paciente: ");
			String name = entrada.next();
			
			//entrada2 recebe o sobrenome do paciente!
			Scanner entrada2 = new Scanner(System.in);
			System.out.println("Informe o sobrenome do "+(i+1)+"� paciente: ");
			String sobrename = entrada2.next();
			
			//entrada3 recebe o sexo do paciente!
			Scanner entrada3 = new Scanner(System.in);
			System.out.println("Informe o sexo do "+(i+1)+"� paciente: ");
			String sex = entrada3.next();
			
			//entradas 4, 5 e 6, recebem os valores da data!
			Scanner entrada4 = new Scanner(System.in);
			System.out.println("Informe o dia em que o "+(i+1)+"� paciente nasceu: ");
			int day = entrada4.nextInt();
			
			Scanner entrada5 = new Scanner(System.in);
			System.out.println("Informe o m�s em que o "+(i+1)+"� paciente nasceu: ");
			int month = entrada5.nextInt();
			
			Scanner entrada6 = new Scanner(System.in);
			System.out.println("Informe o ano em que o "+(i+1)+"� paciente nasceu: ");
			int year = entrada6.nextInt();
			
			HeartRats fixa = new HeartRats(name,sobrename,sex,day,month,year);
			
			System.out.println("Nome do paciente: "+fixa.Namecmplet());
			System.out.println(" ");
			System.out.println("Sexo: "+fixa.Sexo());
			System.out.println("A frequ�ncia cardiaca m�xima do paciente � de "+fixa.Frequencia()+" batimentos por minutos");
			System.out.println("O intervalo da frequ�ncia cardi�ca est� entre "+fixa.Intervalo()+" e "+fixa.Intervalo2()+" batimentos por minuto");
			System.out.println("A idade do paciente � "+fixa.Age()+" ano(s)");
			System.out.println(" ");
			
			
		}
		
		
	}

}
