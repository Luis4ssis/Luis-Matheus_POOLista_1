package exercicio_317;

public class HealthProfile {
	//pessoa
	private String nome;
	private String sobrenome;
	private String sexo;
	//data de nascimento
	private int dia;
	private int mes;
	private int ano;
	//perfil
	private double altura;
	private double peso;
	
	//construtor da class
	public HealthProfile(String nome, String sobrenome, String sexo, int dia, int mes, int ano, double altura, double peso) {

		this.nome = nome;
		this.sobrenome = sobrenome;
		this.sexo = sexo;
		this.dia = dia;
		this.mes = mes;
		this.ano = ano;
		this.altura = altura;
		this.peso = peso;
		
		//get e set
		
	}
	//nome
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	//sobrenome
	public String getSobrenome() {
		return sobrenome;
	}
	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}
	public String getSexo(){
		return sexo;
	}
	public void setSexo(String sexo){
		this.sexo = sexo;
	}
	//data dia
	public int getDia() {
		return dia;
	}
	public void setDia(int dia) {
		this.dia = dia;
	}
	//mes
	public int getMes() {
		return mes;
	}
	public void setMes(int mes) {
		this.mes = mes;
	}
	//ano
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	//altura
	public double getAltura() {
		return altura;
	}
	public void setAltura(double altura) {
		this.altura = altura;
	}
	//peso
	public double getPeso() {
		return peso;
	}
	public void setPeso(double peso) {
		this.peso = peso;
	}
	//informa o nome e sobrenome 
	public String Namecomplet(){
		String nomePaciente = nome +" "+ sobrenome;
		return nomePaciente;
	}
	//informa o sexo
	public String Sexo(){
		String sexoPaciente = sexo;
		return sexoPaciente;
	}
	//extraindo a idade
	public int Age(){
		return 2016 - ano;
	}
	//converte a altura em polegadas
	public double Height(){
		return  39.370 * altura;
	}
	//converte a massa(peso) em libras
	public double Weight(){
		return 2.20462 * peso;
	}
	//frequencia cardiaca
	public int Frequencia(){
		int freqCard = 220 - Age();
		return freqCard;
	}
	/*
	 * frequencia cardiaca alvo
	 * 50% da frequencia cardiaca
	 */ 
	public double Intervalo(){
		double interv = Frequencia() * 0.50;
		return interv;

	}
	//85% da frequencia cardiaca
	public double Intervalo2(){
		double interv2 = Frequencia() * 0.85;
		return interv2;
	}
	//calculo do IMC com a altura em metros e o peso em quilos
	public double IMC(){
		return peso/(altura*altura);
	}

}
