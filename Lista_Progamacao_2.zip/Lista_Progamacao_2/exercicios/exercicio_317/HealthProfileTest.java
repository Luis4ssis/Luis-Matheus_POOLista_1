package exercicio_317;

import java.util.Scanner;
import java.text.DecimalFormat;
public class HealthProfileTest {
	
	public static void main(String[] args){
		
		Scanner scan = new Scanner(System.in);
		DecimalFormat format = new DecimalFormat("0.00");
		
		System.out.println("Informe a quantidade de pacientes que ser�o avaliados: ");
		int quant = scan.nextInt();
		
		for(int i = 0; i < quant; i++){
			Scanner entrada = new Scanner(System.in);
			System.out.println("Insira o nome do "+(i+1)+"� paciente: ");
			String name = entrada.next();
			
			Scanner entrada2 = new Scanner(System.in);
			System.out.println("Insira o sobrenome do "+(i+1)+"� paciente: ");
			String sobrename = entrada2.next();
			
			Scanner entrada3 = new Scanner(System.in);
			System.out.println("Insira o sexo do "+(i+1)+"� paciente: ");
			String sex = entrada3.next();
			
			Scanner entrada4 = new Scanner(System.in);
			System.out.println("Insira o dia em que o "+(i+1)+"� paciente nasceu: ");
			int day  = entrada4.nextInt();
			
			Scanner entrada5 = new Scanner(System.in);
			System.out.println("Insira o m�s em que o "+(i+1)+"� paciente nasceu: ");
			int month  = entrada5.nextInt();
			
			Scanner entrada6 = new Scanner(System.in);
			System.out.println("Insira o ano em que o "+(i+1)+"� paciente nasceu: ");
			int year  = entrada6.nextInt();
			
			Scanner entrada7 = new Scanner(System.in);
			System.out.println("Insira a altura do "+(i+1)+"� paciente: ");
			double height  = entrada7.nextDouble();
			
			Scanner entrada8 = new Scanner(System.in);
			System.out.println("Insira a massa(peso) do "+(i+1)+"� paciente: ");
			double weight = entrada8.nextDouble();
			
			HealthProfile fixa = new HealthProfile(name,sobrename,sex,day,month,year,height,weight);
			
			//resultado da avalia��o
			
			System.out.println(" ");
			System.out.println("Nome do paciente: "+fixa.Namecomplet());//imprime o metodo Namecomplet que fornece o nome e sobrenome
			System.out.println(" ");
			System.out.println("Sexo: "+fixa.Sexo());//imprime o metodo Sexo que fornece o sexo
			System.out.println("A frequ�ncia cardiaca m�xima do paciente � de "+fixa.Frequencia()+" batimentos por minutos");//chama o metodo Frequencia e imprime a frequencia cardiaca maxima
			System.out.println("O intervalo da frequ�ncia cardi�ca est� entre "+format.format(fixa.Intervalo())+" e "+format.format(fixa.Intervalo2())+" bpm");//imprime os metodos Intervalo e Intervalo2 que fornece o primeiro e ultimo valor do intervalo da frequencia cardiaca
			System.out.println("A idade do paciente � "+fixa.Age()+" ano(s)");//imprime o metodo Age que fornece a idade
			System.out.println("A altura do paciente em polegadas � "+format.format(fixa.Height()));//imprime o metodo Height que fornece a altura em polegadas
			System.out.println("O peso do paciente em libras � "+format.format(fixa.Weight()));// imprime o metodo Weitght que fornece o peso em libras
			System.out.println("O �ndice de massa corporal � de "+format.format(fixa.IMC()));// imprime o metodo IMC que fornece o indice de massa corporal
			if(fixa.IMC() < 18.5){
				System.out.println("IMC baixo!");
			}
			if(fixa.IMC() >= 18.5 & fixa.IMC() <= 24.9){
				System.out.println("IMC Normal!");
			}
			if(fixa.IMC() > 25 & fixa.IMC() <= 29.9){
				System.out.println("IMC alto!");
			}
			if(fixa.IMC() > 30){
				System.out.println("IMC elevado, o paciente est� obeso!");
			}
			System.out.println(" ");
			
		}
	}

}
